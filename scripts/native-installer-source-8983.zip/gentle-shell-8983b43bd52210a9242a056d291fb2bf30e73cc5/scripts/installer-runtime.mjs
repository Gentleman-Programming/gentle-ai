import * as fsPromises from "node:fs/promises";
import { join, posix } from "node:path";
import { collectInventory, planPreflight, pnpmGlobalBin } from "./installer-preflight.mjs";
import { createProbes, hostAdapters, userEnvironment } from "./installer-probes.mjs";
import { acquireGo } from "./installer-downloads.mjs";
import { childEnvironment, goFirstEnvironment, lookPath, packageNativeGentleAi, pnpmInvocation, runStandardInstall, upgradeInvocation } from "./installer-runner.mjs";
import { configHome, mainChannelAdapter, runUpgrade } from "./main-channel.mjs";
import { ensureWindowsPnpmHome, windowsWizardEnvironment } from "./installer-windows.mjs";

/** The runner's environment: the user's real PATH, so a temporary bootstrap npm
 * or node never counts as persistent and globalBin.onPath stays truthful. A
 * POSIX bootstrap pnpm (passed only through PATH) comes first: the bootstrap
 * acquired it because the user's pnpm is absent or incompatible, so the user's
 * is never run. Windows passes pnpm through the GENTLE_INSTALL_PNPM_* handoff.
 */
export async function runnerEnvironment({ platform, env, fs }) {
	const user = userEnvironment({ platform, env });
	if (platform === "win32") return user;
	const wizard = await pnpmInvocation(env, platform, fs);
	if (wizard === null || wizard.prefix.length > 0 || (await pnpmInvocation(user, platform, fs))?.command === wizard.command) return user;
	const rest = String(user.PATH ?? "").split(posix.delimiter).filter((entry) => entry.length > 0);
	return { ...user, PATH: [posix.dirname(wizard.command), ...rest].join(posix.delimiter) };
}

/** An update's children: with a private Windows PNPM_HOME, the runner children's
 * environment (pnpm's folders, TEMP and TMP inside it); a pinned Go first on PATH.
 */
export function upgradeEnvironment({ platform, env, pnpmHome, goPath }) {
	const globalBin = platform === "win32" && pnpmHome?.source === "private" ? pnpmGlobalBin({ platform, env }) : null;
	const base = globalBin ? childEnvironment(env, platform, globalBin, { privateHome: true }) : env;
	return goPath ? goFirstEnvironment(base, platform, goPath) : base;
}

/** Shared planner/runner wiring, with no server, browser or automatic installation.
 * Every collection gets fresh probes. The frontend owns consent and must collect
 * again and compare the reviewed plan before calling runInstall (as the web host does).
 * A native frontend must supply its private environment and bounded worker adapters.
 * Optional onInstallationVerified observes only a completed fresh release's
 * verified PNPM locator (see runStandardInstall), not final publication. Consumer
 * errors propagate after installation; retrying runInstall would reinstall.
 */
export function createInstallerRuntime({ platform = process.platform, arch = process.arch,
	env = process.env, nodePath = process.execPath, adapters = hostAdapters(), onInstallationVerified } = {}) {
	if (onInstallationVerified !== undefined && typeof onInstallationVerified !== "function") {
		throw new TypeError("onInstallationVerified must be a function");
	}
	const { run, fs } = adapters;
	let wizard = null;
	return {
		collectPlan: async (channel) => {
			wizard = null; // Failed recollection must not retain a previous decision.
			const decision = platform === "win32" ? windowsWizardEnvironment({ env }) : { env, pnpmHome: null };
			const { env: wizardEnv, pnpmHome } = decision;
			// Fresh probes every time: createProbes caches its global package listing.
			const inventory = await collectInventory({ platform, arch, probes: createProbes({ platform, env: wizardEnv, run, fs, pnpmHome }), pnpmHome });
			const plan = planPreflight(inventory, { channel });
			wizard = decision;
			return { inventory, plan };
		},
		runInstall: async (request, log) => {
			if (wizard === null) throw new Error("Collect an installation plan before running");
			const { env: wizardEnv, pnpmHome } = wizard;
			const runnerEnv = await runnerEnvironment({ platform, env: wizardEnv, fs });
			const ctx = { env: runnerEnv, home: runnerEnv.HOME ?? env.HOME ?? env.USERPROFILE };
			return runStandardInstall(request, {
			platform,
			nodePath,
			env: runnerEnv,
			run,
			fs,
			onInstallationVerified,
			// An existing Gentle Shell: fresh probes find it, `gentle-shell upgrade`'s logic updates it.
			locateShell: () => createProbes({ platform, env: wizardEnv, run, fs, pnpmHome }).locateShell(),
			// An older Pi: fresh probes find it before its update and confirm it afterwards.
			locatePi: () => createProbes({ platform, env: wizardEnv, run, fs, pnpmHome }).locatePi(),
			// Only a plan with a private Windows PNPM_HOME: claimed, then walked again.
			preparePnpmHome: (home) => ensureWindowsPnpmHome(home, runnerEnv),
			// Only a plan that needs Go and found it missing or older: verified go.dev
			// bytes under <config home>/tools/go, used by path or child PATH only.
			acquireGo: () => acquireGo({ root: join(configHome(ctx), "tools", "go"), platform, arch }),
			// A pinned Go goes first on the PATH of the upgrade's children only. On
			// Windows npm and pnpm (the bootstrap's handoff) run without cmd.exe.
			upgradeShell: async ({ channel, packageRoot, currentVersion, goPath }) => {
				const upgradeEnv = upgradeEnvironment({ platform, env: runnerEnv, pnpmHome, goPath });
				const invocation = upgradeInvocation({ platform, env: upgradeEnv, run, fs, handoff: true });
				return (await runUpgrade({
					args: ["--channel", channel],
					ctx,
					platform,
					arch,
					packageRoot,
					currentVersion,
					adapters: {
						fetch: globalThis.fetch,
						fs: fsPromises,
						which: (name) => lookPath(name, upgradeEnv, platform, fs),
						...(invocation ? { invocation } : {}),
						// stderrTail: a failed main build or extraction keeps its bounded stderr as the error's cause.
						run: (command, argv, options = {}) => run(command, argv, { env: options.env ?? upgradeEnv, cwd: options.cwd, deadlineMs: options.deadlineMs ?? 20 * 60_000,
							...(options.stderrTail === undefined ? {} : { stderrTail: options.stderrTail }) }),
					},
					out: () => {},
				})) === 0;
			},
			verifyGentleAi: packageNativeGentleAi,
			// Only a main plan uses it: network access and writes under ~/.pi/gentle-ai.
			mainChannel: mainChannelAdapter({ fs: fsPromises }),
			log,
		});
		},
	};
}
