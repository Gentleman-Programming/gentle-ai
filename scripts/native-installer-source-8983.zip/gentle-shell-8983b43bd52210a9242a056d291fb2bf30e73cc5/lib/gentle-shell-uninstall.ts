import { lstatSync, readdirSync, readFileSync, realpathSync, rmdirSync, rmSync } from "node:fs";
import { createInterface } from "node:readline";
import { basename, dirname, isAbsolute, join, relative, resolve } from "node:path";
import { isolatedDir, launcherConfigPath, parseRawLauncherConfig, provisionedEntry, userPiHome } from "./gentle-shell-launcher.ts";

// `gentle-shell self-uninstall`: removes what Gentle Shell itself created, then
// the gentle-pi package with the package manager that owns it. Everything is
// planned and printed before anything is removed. Removal follows the
// installer's safe-deletion model (scripts/installer-downloads.mjs
// removeOwnedTools): exact paths only, lstat first, symbolic links are never
// followed or removed, and rmSync never follows links inside a directory.
// `gentle-shell uninstall <source>` stays pi's own alias for `remove`.

export const SELF_UNINSTALL_USAGE = "usage: gentle-shell self-uninstall [--dry-run] [--yes] [--include-shared]";

/** Gentle AI configuration in the config home that Pi without Gentle Shell can share. */
export const SHARED_CONFIG_FILES: readonly string[] = Object.freeze([
	"profiles.json",
	"profiles.export.json",
	"banner.json",
	"builtin-codemode-optout.json",
	"background-subagents.json",
	"double-esc-cancel.json",
	"runtime-guardrails.json",
	"persona.json",
]);

const HOME_OWNERSHIP_MARKER = ".gentle-shell-home";
// scripts/installer-downloads.mjs marks each pinned Go version folder with it.
const GO_MARKER = ".gentle-shell-go";
const GO_VERSION = /^(0|[1-9]\d*)\.(0|[1-9]\d*)(\.(0|[1-9]\d*))?$/;
const COMMIT = /^[0-9a-f]{40}$/;
const PACKAGE = "gentle-pi";

export interface SelfUninstallOptions {
	dryRun: boolean;
	yes: boolean;
	includeShared: boolean;
}

export function parseSelfUninstallArgs(args: readonly string[]): SelfUninstallOptions | { error: string } {
	const options = { dryRun: false, yes: false, includeShared: false };
	for (const arg of args) {
		if (arg === "--dry-run") options.dryRun = true;
		else if (arg === "--yes") options.yes = true;
		else if (arg === "--include-shared") options.includeShared = true;
		else return { error: `unknown argument ${arg}; ${SELF_UNINSTALL_USAGE}` };
	}
	return options;
}

/** How the owning package manager runs: `command` with `prefix` before its own
 * arguments (on Windows, node.exe and the manager's JS entry, never a .cmd). */
export interface PackageManagerOwner {
	name: "pnpm" | "npm";
	command: string;
	prefix: string[];
}

export interface RunResult {
	code: number | null;
	timedOut?: boolean;
	signal?: string | null;
}

export interface SelfUninstallInput {
	args: readonly string[];
	env: Record<string, string | undefined>;
	homedir: string;
	platform: string;
	/** Whether a person can answer questions (stdin is a terminal). */
	interactive: boolean;
	/** The package manager that owns gentle-pi; throws an Error to refuse. */
	resolveOwner: () => Promise<PackageManagerOwner>;
	run: (command: string, argv: string[]) => Promise<RunResult>;
	/** Resolves the typed line ("" at end of input); rejects with PromptInterrupted on Ctrl-C. */
	ask: (question: string) => Promise<string>;
	out: (line: string) => void;
	err: (line: string) => void;
}

interface Removal {
	path: string;
	label: string;
	kind: "dir" | "file";
	/** Remove the parent directory too when this leaves it empty. */
	pruneParent?: boolean;
	/** Evidence that Gentle Shell made it; without it the path is kept with this reason. */
	evidence?: { made: (path: string) => boolean; otherwise: string };
}

interface Guard {
	path: string;
	label: string;
	/** Whether lying inside `path` is refused too (being it or containing it always is). */
	inside: boolean;
}

interface NotTouched {
	path?: string;
	label: string;
}

interface Plan {
	refusals: string[];
	/** A removal would reach a protected path: the removal list is not offered at all. */
	pathRefused: boolean;
	own: Removal[];
	kept: string[];
	shared: Removal[];
	configHome: string;
	owner?: PackageManagerOwner;
	notTouched: NotTouched[];
	manual: string[];
}

function comparable(path: string, platform: string): string {
	return platform === "win32" ? path.toLowerCase() : path;
}

/** The real path, resolving the nearest existing ancestor when `path` does not exist. */
function canonical(path: string): string {
	const absolute = resolve(path);
	const rest: string[] = [];
	let current = absolute;
	for (;;) {
		try {
			return join(realpathSync(current), ...rest);
		} catch {
			const parent = dirname(current);
			if (parent === current) return absolute;
			rest.unshift(basename(current));
			current = parent;
		}
	}
}

/** True when `child` is `parent` itself or lies inside it. */
function within(parent: string, child: string, platform: string): boolean {
	const path = relative(comparable(parent, platform), comparable(child, platform));
	return path === "" || (!path.startsWith("..") && !isAbsolute(path));
}

type Inspection = "ok" | "missing" | "symlink" | "other";

function inspect(path: string, kind: "dir" | "file"): Inspection {
	let info;
	try {
		info = lstatSync(path);
	} catch {
		return "missing";
	}
	if (info.isSymbolicLink()) return "symlink";
	return (kind === "dir" ? info.isDirectory() : info.isFile()) ? "ok" : "other";
}

function readText(path: string): string | undefined {
	try {
		return readFileSync(path, "utf8");
	} catch {
		return undefined;
	}
}

/** An absolute directory from `env[name]`, the fallback when unset or empty, or undefined when relative. */
function settingDirectory(env: Record<string, string | undefined>, name: string, fallback: string): string | undefined {
	const value = env[name];
	if (value === undefined || value === "") return fallback;
	return isAbsolute(value) ? value : undefined;
}

function entries(path: string): string[] {
	try {
		return readdirSync(path);
	} catch {
		return ["\0unreadable"];
	}
}

/** Only what the main channel writes (scripts/main-channel.mjs): gentle-ai/<commit>/gentle-ai[.exe],
 * packages/gentle-pi-*.tgz, and the .build and .source work folders. */
function mainChannelLayout(main: string): boolean {
	return entries(main).every((name) => {
		const path = join(main, name);
		if (inspect(path, "dir") !== "ok") return false;
		if (name === ".build" || name === ".source") return true;
		if (name === "packages") return entries(path).every((file) => /^gentle-pi-.+\.tgz$/.test(file) && inspect(join(path, file), "file") === "ok");
		if (name !== "gentle-ai") return false;
		return entries(path).every((commit) => COMMIT.test(commit) && inspect(join(path, commit), "dir") === "ok"
			&& entries(join(path, commit)).every((file) => ["gentle-ai", "gentle-ai.exe"].includes(file) && inspect(join(path, commit, file), "file") === "ok"));
	});
}

/** Only pinned-Go version folders, each carrying the installer's marker. */
function pinnedGoOnly(go: string): boolean {
	return entries(go).every((name) => GO_VERSION.test(name) && inspect(join(go, name), "dir") === "ok" && inspect(join(go, name, GO_MARKER), "file") === "ok");
}

/** How `real` collides with a guard: it is it, contains it, or (for guards that say so) lies inside it. */
function collision(real: string, guards: readonly Guard[], platform: string): string | undefined {
	for (const guard of guards) {
		const target = canonical(guard.path);
		const relation = comparable(real, platform) === comparable(target, platform) ? "is"
			: within(real, target, platform) ? "contains"
			: guard.inside && within(target, real, platform) ? "lies inside" : undefined;
		if (relation) return `${relation} ${guard.path} (${guard.label})`;
	}
	return undefined;
}

/** A `.pi` directory (a project's `.pi`, `.pi/gentle-ai`, or the user's `~/.pi`) is never removed or emptied. */
function piDirectoryCollision(real: string, platform: string, allowedInside: string | undefined): string | undefined {
	const segments = real.split(/[\\/]+/).filter((segment) => segment !== "");
	const isPi = (segment: string | undefined) => segment !== undefined && comparable(segment, platform) === ".pi";
	const exempt = allowedInside !== undefined && comparable(real, platform) === comparable(allowedInside, platform);
	if (!exempt && isPi(segments.at(-1))) return "is a .pi directory";
	if (!exempt && segments.slice(0, -1).some(isPi)) return "lies inside a .pi directory";
	if (inspect(join(real, ".pi"), "dir") !== "missing") return `contains a .pi directory (${join(real, ".pi")})`;
	return undefined;
}

/** Whether the main-channel override in `dev-binary.json` points at a build under `<config home>/main/gentle-ai`. */
function mainChannelRegistration(path: string, configHome: string, platform: string): boolean {
	try {
		const registration = JSON.parse(readText(path) ?? "null");
		if (typeof registration?.path !== "string") return false;
		const builds = join(configHome, "main", "gentle-ai");
		return within(builds, registration.path, platform) && resolve(registration.path) !== resolve(builds);
	} catch {
		return false;
	}
}

async function planSelfUninstall(input: SelfUninstallInput, configHome: string, isolated: string): Promise<Plan> {
	const { env, homedir, platform } = input;
	const plan: Plan = { refusals: [], pathRefused: false, own: [], kept: [], shared: [], configHome, notTouched: [], manual: [] };
	const configPath = launcherConfigPath(homedir);
	const shellDirectory = dirname(configPath);
	const launcherConfig = parseRawLauncherConfig(readText(configPath));
	const piHome = userPiHome(env, homedir);
	const gentleAiState = join(homedir, ".gentle-ai");
	const isolatedReal = canonical(isolated);

	// Every place a removal starts from is checked at its real path, so a symbolic
	// link (or a symlinked ancestor) never leads it somewhere protected.
	// Inside a Gentle Shell session PI_CODING_AGENT_DIR is the isolated home itself
	// and the user's Pi home travels in GENTLE_SHELL_USER_PI_HOME (see userPiHome).
	// Only an existing directory other than the isolated home proves that session.
	const sessionPiHome = env.GENTLE_SHELL_USER_PI_HOME ? canonical(env.GENTLE_SHELL_USER_PI_HOME) : null;
	const inSession = sessionPiHome !== null && inspect(sessionPiHome, "dir") === "ok"
		&& comparable(sessionPiHome, platform) !== comparable(isolatedReal, platform);
	const sessionAgentDir = (name: string, value: string) => name === "PI_CODING_AGENT_DIR" && inSession
		&& comparable(canonical(value), platform) === comparable(isolatedReal, platform);
	const guards: Guard[] = [
		{ path: homedir, label: "your home directory", inside: false },
		{ path: join(homedir, ".pi", "agent"), label: "Pi's default home", inside: true },
		...["PI_CODING_AGENT_DIR", "GENTLE_SHELL_USER_PI_HOME"].flatMap((name) => {
			const value = env[name];
			return value && !sessionAgentDir(name, value) ? [{ path: value, label: "your Pi home", inside: true }] : [];
		}),
		{ path: gentleAiState, label: "Gentle AI's state", inside: true },
	];
	const defaultConfigHome = canonical(join(homedir, ".pi", "gentle-ai"));
	const candidates = [
		{
			who: env.GENTLE_SHELL_HOME ? `GENTLE_SHELL_HOME points at ${isolated}` : `The isolated home ${isolated}`,
			path: isolated,
			guards: [...guards, { path: configHome, label: "the Gentle AI config home", inside: true }],
			allowedInsidePi: undefined,
		},
		{
			who: env.GENTLE_PI_CONFIG_HOME ? `GENTLE_PI_CONFIG_HOME points at ${configHome}` : `The config home ${configHome}`,
			path: configHome,
			guards,
			// Its default location, ~/.pi/gentle-ai, is the one .pi path it may be.
			allowedInsidePi: defaultConfigHome,
		},
		{ who: `The launcher folder ${shellDirectory}`, path: shellDirectory, guards, allowedInsidePi: undefined },
	];
	for (const candidate of candidates) {
		const real = canonical(candidate.path);
		const reason = collision(real, candidate.guards, platform) ?? piDirectoryCollision(real, platform, candidate.allowedInsidePi);
		if (reason === undefined) continue;
		const really = comparable(real, platform) === comparable(resolve(candidate.path), platform) ? "" : ` (really ${real})`;
		plan.refusals.push(`${candidate.who}${really}, which ${reason}; refusing to remove anything.`);
	}

	const consider = (removal: Removal) => {
		const state = inspect(removal.path, removal.kind);
		if (state === "ok" && removal.evidence && !removal.evidence.made(removal.path)) plan.kept.push(`${removal.path}: ${removal.evidence.otherwise}`);
		else if (state === "ok") plan.own.push(removal);
		else if (state === "symlink") plan.kept.push(`${removal.path}: a symbolic link, not followed`);
		else if (state === "other") plan.kept.push(`${removal.path}: not a ${removal.kind === "dir" ? "directory" : "regular file"}`);
	};
	consider({
		path: join(configHome, "main"), label: "main-channel builds", kind: "dir",
		evidence: { made: mainChannelLayout, otherwise: "not Gentle Shell's main-channel layout" },
	});
	consider({ path: join(configHome, "channel.json"), label: "recorded update channel", kind: "file" });
	const devBinary = join(configHome, "dev-binary.json");
	if (inspect(devBinary, "file") !== "ok" || mainChannelRegistration(devBinary, configHome, platform)) {
		consider({ path: devBinary, label: "main-channel Gentle AI override", kind: "file" });
	} else {
		plan.kept.push(`${devBinary}: points at a binary you registered yourself`);
	}
	consider({
		path: join(configHome, "tools", "go"), label: "Go the installer downloaded for builds", kind: "dir", pruneParent: true,
		evidence: { made: pinnedGoOnly, otherwise: `not only the installer's pinned Go (version folders marked ${GO_MARKER})` },
	});

	// The default isolated home is Gentle Shell's by location; a GENTLE_SHELL_HOME
	// directory only with the launcher's ownership marker or setup record.
	const defaultHome = resolve(isolated) === resolve(join(homedir, ".gentle-shell", "agent"));
	const owned = defaultHome || inspect(join(isolated, HOME_OWNERSHIP_MARKER), "file") === "ok"
		|| provisionedEntry(launcherConfig, isolatedReal) !== undefined;
	if (owned || inspect(isolated, "dir") !== "ok") consider({ path: isolated, label: "isolated home: its sign-ins, chats and settings", kind: "dir" });
	else plan.kept.push(`${isolated}: not created by Gentle Shell (no ${HOME_OWNERSHIP_MARKER} marker or setup record)`);
	consider({ path: configPath, label: "launcher settings", kind: "file" });

	for (const name of SHARED_CONFIG_FILES) {
		const path = join(configHome, name);
		if (inspect(path, "file") === "ok") plan.shared.push({ path, label: name, kind: "file" });
	}

	const seen = new Set([comparable(isolatedReal, platform), comparable(canonical(piHome), platform)]);
	plan.notTouched.push({ path: piHome, label: "your Pi home" });
	const customHomes = [typeof launcherConfig.home === "string" && !["link", "isolated", ""].includes(launcherConfig.home) ? launcherConfig.home : undefined];
	const provisioned = launcherConfig.provisioned;
	if (typeof provisioned === "object" && provisioned !== null && !Array.isArray(provisioned)) customHomes.push(...Object.keys(provisioned));
	for (const home of customHomes) {
		if (home === undefined || !isAbsolute(home)) continue;
		const key = comparable(canonical(home), platform);
		if (seen.has(key)) continue;
		seen.add(key);
		plan.notTouched.push({ path: home, label: "custom --home home" });
	}
	plan.notTouched.push({ path: gentleAiState, label: "Gentle AI's own state" }, { label: "Each project's .pi/gentle-ai folder" });

	// Nothing is both removed and not touched: a removal that is, holds or lies
	// inside a path listed as not touched refuses the whole run.
	if (plan.refusals.length === 0) {
		for (const removal of [...plan.own, ...plan.shared]) {
			const real = canonical(removal.path);
			for (const kept of plan.notTouched) {
				if (kept.path === undefined) continue;
				const target = canonical(kept.path);
				if (!within(real, target, platform) && !within(target, real, platform)) continue;
				plan.refusals.push(`${removal.path} would be removed, but it overlaps ${kept.path} (${kept.label}), which is not touched; refusing to remove anything.`);
			}
		}
	}
	plan.pathRefused = plan.refusals.length > 0;

	plan.manual.push(
		"Pi: pnpm remove -g @earendil-works/pi-coding-agent (or npm uninstall -g @earendil-works/pi-coding-agent)",
		"Engram, installed by Gentle AI's setup: remove the engram binary on your PATH",
		platform === "win32"
			? "The PATH entry from `pnpm setup`: remove PNPM_HOME and its PATH entry from your user environment variables"
			: "The PATH entry from `pnpm setup`: remove the PNPM_HOME lines it added to your shell profile",
	);
	if (platform === "win32") {
		plan.manual.push("%USERPROFILE%\\.pnpm, the private pnpm home the installer may have chosen: delete it after removing the packages above");
	}

	try {
		plan.owner = await input.resolveOwner();
	} catch (error) {
		plan.refusals.push(`The ${PACKAGE} package cannot be removed: ${error instanceof Error ? error.message : String(error)}`);
	}
	return plan;
}

function removeArgv(owner: PackageManagerOwner): string[] {
	return owner.name === "pnpm" ? ["remove", "-g", PACKAGE] : ["uninstall", "-g", PACKAGE];
}

function printPlan(plan: Plan, options: SelfUninstallOptions, interactive: boolean, out: (line: string) => void) {
	out("Gentle Shell self-uninstall plan");
	out("Remove Gentle Shell data:");
	if (plan.pathRefused) out("  (refused, see below)");
	else if (plan.own.length === 0) out("  (nothing found)");
	for (const removal of plan.pathRefused ? [] : plan.own) out(`  ${removal.path}  (${removal.label})`);
	out(`Remove the ${PACKAGE} package:`);
	out(plan.owner ? `  ${plan.owner.name} ${removeArgv(plan.owner).join(" ")}` : "  (refused, see below)");
	if (plan.shared.length > 0 && !plan.pathRefused) {
		const disposition = options.includeShared
			? "removed (--include-shared)"
			: options.yes || !interactive ? "kept; pass --include-shared to remove it" : "kept unless you accept when asked";
		out(`Shared Gentle AI configuration in ${plan.configHome}, ${disposition}:`);
		for (const removal of plan.shared) out(`  ${removal.path}`);
	}
	if (plan.kept.length > 0) {
		out("Kept:");
		for (const line of plan.kept) out(`  ${line}`);
	}
	out("Not touched:");
	for (const kept of plan.notTouched) out(kept.path === undefined ? `  ${kept.label}` : `  ${kept.path}  (${kept.label})`);
	out("The installer may also have added these; remove them yourself if nothing else uses them:");
	for (const line of plan.manual) out(`  ${line}`);
}

/** Removes one planned path without following links; re-checks it right before removal. */
function remove(removal: Removal) {
	const state = inspect(removal.path, removal.kind);
	if (state === "missing") return;
	if (state !== "ok") throw new Error("it changed after the plan was made");
	if (removal.kind === "dir") rmSync(removal.path, { recursive: true });
	else rmSync(removal.path);
	if (removal.pruneParent) removeIfEmpty(dirname(removal.path));
}

function removeIfEmpty(directory: string) {
	if (inspect(directory, "dir") === "ok" && readdirSync(directory).length === 0) rmdirSync(directory);
}

/** Ctrl-C at a question: the whole uninstall stops. */
export class PromptInterrupted extends Error {
	constructor() {
		super("interrupted");
		this.name = "PromptInterrupted";
	}
}

/**
 * Asks one question on `input` and returns the typed line. End of input (Ctrl-D,
 * a closed stdin) answers "", which every question reads as No; Ctrl-C rejects
 * with PromptInterrupted. `terminal` follows readline (default: output.isTTY).
 */
export function askLine(question: string, streams: { input: NodeJS.ReadableStream; output: NodeJS.WritableStream; terminal?: boolean }): Promise<string> {
	const input = streams.input as NodeJS.ReadableStream & { readableEnded?: boolean; destroyed?: boolean };
	if (input.readableEnded === true || input.destroyed === true) return Promise.resolve("");
	return new Promise((resolveAnswer, reject) => {
		let settled = false;
		const prompt = createInterface({ input: streams.input, output: streams.output, terminal: streams.terminal });
		prompt.once("SIGINT", () => {
			if (settled) return;
			settled = true;
			prompt.close();
			reject(new PromptInterrupted());
		});
		prompt.once("close", () => {
			if (settled) return;
			settled = true;
			resolveAnswer("");
		});
		prompt.question(question, (answer) => {
			if (settled) return;
			settled = true;
			prompt.close();
			resolveAnswer(answer);
		});
	});
}

function isYes(answer: string): boolean {
	return /^(y|yes)$/i.test(answer.trim());
}

function succeeded(result: RunResult): boolean {
	return result.code === 0 && result.timedOut !== true && result.signal == null;
}

/**
 * Runs `gentle-shell self-uninstall`. Exit codes: 0 done or dry run, 1 refused,
 * cancelled or failed, 2 usage (including no terminal without --yes).
 */
export async function runSelfUninstall(input: SelfUninstallInput): Promise<number> {
	const { env, homedir, out, err } = input;
	const options = parseSelfUninstallArgs(input.args);
	if ("error" in options) {
		err(`gentle-shell self-uninstall: ${options.error}`);
		return 2;
	}
	const configHome = settingDirectory(env, "GENTLE_PI_CONFIG_HOME", join(homedir, ".pi", "gentle-ai"));
	const isolated = settingDirectory(env, "GENTLE_SHELL_HOME", isolatedDir(env, homedir));
	if (configHome === undefined || isolated === undefined) {
		const name = configHome === undefined ? "GENTLE_PI_CONFIG_HOME" : "GENTLE_SHELL_HOME";
		err(`gentle-shell self-uninstall: ${name}=${env[name]} is not an absolute path; refusing to remove anything.`);
		return 1;
	}

	const plan = await planSelfUninstall(input, configHome, isolated);
	printPlan(plan, options, input.interactive, out);
	if (plan.refusals.length > 0 || plan.owner === undefined) {
		for (const line of plan.refusals) err(`gentle-shell self-uninstall: ${line}`);
		err("Nothing was removed.");
		return 1;
	}
	if (options.dryRun) {
		out("Dry run: nothing was removed.");
		return 0;
	}
	let includeShared = options.includeShared;
	if (!options.yes) {
		if (!input.interactive) {
			err("gentle-shell self-uninstall: no terminal to confirm in; pass --yes to remove the above, or --dry-run to only show it.");
			return 2;
		}
		try {
			if (!isYes(await input.ask("Remove Gentle Shell as listed above? [y/N] "))) {
				out("Cancelled; nothing was removed.");
				return 1;
			}
			if (plan.shared.length > 0 && !includeShared) {
				includeShared = isYes(await input.ask(`Also remove the shared Gentle AI configuration in ${plan.configHome} listed above? [y/N] `));
			}
		} catch (error) {
			if (!(error instanceof PromptInterrupted)) throw error;
			err("gentle-shell self-uninstall: Interrupted; nothing was removed.");
			return 1;
		}
	}

	for (const removal of [...plan.own, ...(includeShared ? plan.shared : [])]) {
		try {
			remove(removal);
		} catch (error) {
			err(`gentle-shell self-uninstall: could not remove ${removal.path}: ${error instanceof Error ? error.message : String(error)}`);
			err(`The ${PACKAGE} package and everything listed after it were kept; fix the cause and run gentle-shell self-uninstall again.`);
			return 1;
		}
	}

	const command = `${plan.owner.name} ${removeArgv(plan.owner).join(" ")}`;
	let removed = false;
	try {
		removed = succeeded(await input.run(plan.owner.command, [...plan.owner.prefix, ...removeArgv(plan.owner)]));
	} catch {
		removed = false;
	}
	if (!removed) {
		err(`gentle-shell self-uninstall: ${plan.owner.name} could not remove the ${PACKAGE} package. Gentle Shell's data was removed; remove the package yourself with: ${command}`);
		return 1;
	}
	try {
		removeIfEmpty(dirname(launcherConfigPath(homedir)));
	} catch {
		// A leftover empty ~/.gentle-shell is harmless.
	}
	out("Gentle Shell was removed.");
	return 0;
}
